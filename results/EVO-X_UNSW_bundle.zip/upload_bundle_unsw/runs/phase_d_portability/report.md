# Phase D1 portability (REAL, >=6 seeds)

Reference dataset: **CICIDS2017**. 'Holds' means the same-sign advantage keeps at least 50% of the reference size; margin 0.01.

| Dataset | Algorithm | EVO-X F1 | Best-fixed F1 | Advantage | Reference | Verdict | Cost ratio |
|---|---|---:|---:|---:|---:|---|---:|
| CICIDS2017 | random_forest | 0.7007 | 0.7501 | -0.0494 | -0.0494 | reference | 0.06 |
| UNSW-NB15 | random_forest | 0.5236 | 0.5774 | -0.0537 | -0.0494 | none | 0.00 |

## Per drift kind (vs best fixed policy in hindsight)

| Dataset | Algorithm | Kind | Advantage | Verdict |
|---|---|---|---:|---|
| CICIDS2017 | random_forest | abrupt | -0.0433 | reference |
| CICIDS2017 | random_forest | gradual | -0.0178 | reference |
| CICIDS2017 | random_forest | incremental | -0.0308 | reference |
| CICIDS2017 | random_forest | novel_class | -0.1303 | reference |
| CICIDS2017 | random_forest | recurring | -0.0306 | reference |
| CICIDS2017 | random_forest | stationary | -0.0161 | reference |
| CICIDS2017 | random_forest | temporary | -0.0549 | reference |
| UNSW-NB15 | random_forest | abrupt | -0.0787 | none |
| UNSW-NB15 | random_forest | gradual | -0.0743 | none |
| UNSW-NB15 | random_forest | incremental | -0.0173 | none |
| UNSW-NB15 | random_forest | novel_class | -0.1104 | none |
| UNSW-NB15 | random_forest | recurring | -0.0544 | none |
| UNSW-NB15 | random_forest | stationary | +0.0000 | none |
| UNSW-NB15 | random_forest | temporary | -0.0051 | none |

The advantage is reported per dataset and per drift kind and is never averaged across datasets. `best_fixed` picks, for every scenario, the best fixed policy in hindsight (the strictest comparison). Runs on synthetic data, quick runs, or fewer than six seeds validate the pipeline only. Datasets differ in features, attack families and (for UNSW-NB15) categorical columns dropped by the adapter.
